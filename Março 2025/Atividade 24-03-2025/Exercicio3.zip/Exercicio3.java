/* Considere a classe Vetor como está definida no slide 49 da segunda aula.
    a. Adicione um getter e um setter para o atributo elementos. Lembre que, ao modificar esse atributo, 
       deve-se também modificar o atributo tamanho. Para te ajudar, todo vetor em Java já possui um atributo
       públido lenght que guarda o tamanho do vetor (acesse com elementos.lenght).

    b. Sem apagar o método construtor, crie um novo método construtor com o mesmo nome, porém com dois argumentos
       inteiros, tamanho e valor. Esse método deve inicializar o atributo elementos com o tamanho especificado e preencher
       cada posição do vetor com o valor especificado.

    c. Modifique o método setTamanho da seguinte maneira:
        Caso o novo tamanho seja menor que o tamanho atual, apenas crie um novo vetor com o novo tamanho.
        Caso o novo tamanho seja maior que o tamanho atual, crie um novo vetor e copie todos os elementos 
        do vetor antigo para as primeiras posições do vetor novo, em ordem.
 */
package com.mycompany.exercicio3;

public class Exercicio3 {

    public class Vetor {

        private int tamanho;
        private int[] elementos;

        public Vetor(int tamanho) {
            this.tamanho = tamanho;
            this.elementos = new int[tamanho];
        }

        public Vetor(int tamanho, int valor) {
            this.tamanho = tamanho; //Definindo o tamanho do vetor
            this.elementos = new int[tamanho]; //Criando o vetor com o tamanho

            /*Preenchimento do vetor com o valor*/
            for (int i = 0; i < tamanho; i++) {
                /* Percorre todas as posições do vetor elementos e atribui o valor passado como argumento
                    (no caso, valor) a cada uma dessas posições. O índice i ajuda a apontar a posição específica dentro do vetor onde o valor
                    deve ser armazenado.
                 */
                this.elementos[i] = valor;
            }

        }

        public int[] getElementos() {
            return elementos;
        }

        public void setElementos(int[] elementos) {
            this.tamanho = elementos.length;
            this.elementos = new int[tamanho];

            /* O int i = 0 -> inicializa a variável i com 0. Essa variável será usada para percorrer os índices do vetor.
            i < tamanho -> define a condição para que o loop continue rodando, ou seja, o loop vai rodar enquanto i for menor que tamanho. Como tamanho é o número de elementos do vetor, isso garante que vamos copiar todos os valores
            i++ -> A cada repetição do loop, i aumenta em 1. Isso faz com que a gente vá percorrendo todas as posições do vetor.
             */
            System.arraycopy(elementos, 0, this.elementos, 0, tamanho); /* Copiando o valor de elementos[i] (o vetor recebido como parâmetro) para this.elementos[i] (o vetor da nossa classe).
            Se elementos tiver {1, 2, 3}, essa linha vai copiar cada valor para this.elementos, garantindo que os dois vetores sejam iguais.
             */
        }

        public int getTamanho() {
            return tamanho;
        }

        public void setTamanho(int tamanho) {
            int tamanhoAntigo = this.tamanho; //Armazenando o tamanho atual que é o this.tamanho antes de alterá-lo
            int[] elementosAntigos = this.elementos;
            this.tamanho = tamanho;
          
            this.elementos = new int[tamanho];

            if (tamanho > tamanhoAntigo) {
                System.arraycopy(elementosAntigos, 0, this.elementos, 0, tamanhoAntigo);
            }
        }
    }
            
        
    
